package com.example.nad;
import java.util.ArrayList;
import java.util.List;
public class Data {
    public static List<Reguler> getRegulerList() {
        List<Reguler> regulerList = new ArrayList<>();

        Reguler Lima = new Reguler();
        Lima.setName("5jam");
        regulerList.add(Lima);

        Reguler sehari = new Reguler();
        sehari.setName("Sehari Jadi");
        regulerList.add(sehari);

        Reguler dua = new Reguler();
        dua.setName("2 Hari");
        regulerList.add(dua);

        return regulerList;
    }
}
